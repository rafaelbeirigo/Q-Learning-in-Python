*PRQL
**Parâmetros utilizados para experimentos de 01 a 05:
    alpha            = 0.05
    gamma            = 0.95
    epsilon          = 0.0
    epsilonIncrement = 0.0005
    K                = 2000     # number of episodes
    H                = 100      # number of steps
    gammaPRQL        = 0.95
    tau              = 0.0
    deltaTau         = 5
    psi              = 1.0
    v                = 0.95

**Bibliotecas de políticas ([Experimento]:[Políticas]):
01: 1,2,3,4,5
02: 2,3,4
03: 1,2,3,4
04: 2,3,4,5

